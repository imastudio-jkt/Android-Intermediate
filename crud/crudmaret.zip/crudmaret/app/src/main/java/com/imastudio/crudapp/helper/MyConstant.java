package com.imastudio.crudapp.helper;

/**
 * Created by Blackswan on 9/12/2017.
 */

public class MyConstant {
    public static final String BASE_URL = "http://192.168.60.142/db_makananlanjutan/";
    public static final String IMAGE_URL = BASE_URL+"uploads/";
    public static final int REQ_FILE_CHOOSE = 100;
    public static final int STORAGE_PERMISSION_CODE = 2;
    public static final String UPLOAD_URL ="http://192.168.60.130/db_makananlanjutan/uploadmakanan.php" ;
    public static final String UPLOAD_UPDATE_URL = "http://192.168.60.130/db_makananlanjutan/uploadupdatemakanan.php";
}
