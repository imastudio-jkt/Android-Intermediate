package com.imastudio.firebase2019jan.admob;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class RewardVideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
