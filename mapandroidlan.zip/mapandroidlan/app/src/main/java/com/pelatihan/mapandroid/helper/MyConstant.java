package com.pelatihan.mapandroid.helper;

/**
 * Created by Blackswan on 9/12/2017.
 */

public class MyConstant {
    public static final String BASE_URL = "https://maps.googleapis.com/maps/api/directions/";

    public static final int REQ_AWAL = 1;
    public static final int REQ_AKHIR = 2;
    public static final int REQ_PICKER = 2;
    public static final int REQUEST_LOCATION = 3;
}
